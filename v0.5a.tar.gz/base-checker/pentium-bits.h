void emitbits(unsigned long val, unsigned n);
